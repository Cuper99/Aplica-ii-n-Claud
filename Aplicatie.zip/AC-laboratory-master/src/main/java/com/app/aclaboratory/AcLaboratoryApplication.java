package com.app.aclaboratory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AcLaboratoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(AcLaboratoryApplication.class, args);
	}

}
